<!DOCTYPE html>

<html>
  
  <style>
  body {font-family: Arial, Helvetica, sans-serif;}
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }
    
  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>
  
  <?php
    //require_once('database.php'); 

    session_start();

    // connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

    // initializing variables
    $email=$_SESSION['email'];
    $taskName = "";
    $result_user = "";
    $category = "";
    $dueDate = "";
    $priority = "";
    $descr = "";
    $errors = array(); 
  ?>
 
  <body>
    <form action="adminEditUser.php" style="border:1px solid #ccc" method="post"> 
      
    <div class="container">
        <h1>Edit a User</h1>
        <hr>
      
        <?php
          // Find users
          $result = $db->query("SELECT * From User");
          
        ?>
      
          <label for="userID"><b>User</b></label>
            <select name = "userID">
              <?php
                while($row=mysqli_fetch_assoc($result)){
                  ?>
                  <option value = "<?php echo $row['userID'];?>"><?php echo $row['firstName']; echo " "; echo $row['lastName']; ?> </option>
                  <?php
                }
              ?>
            </select>
            <br>
            <br>
      
            <label for="newFirstName"><b> New First Name</b></label>
            <input type="text" placeholder="Enter New First Name" name="newFirstName">
      
            <label for="newLastName"><b> New Last Name</b></label>
            <input type="text" placeholder="Enter New Last Name" name="newLastName"> 

            <div class="clearfix">
              <button type="button" class="backbtn"><a href="adminPage.html">Back</a></button>
              <button type="submit" class="signupbtn" name="adminEditUser" formmethod="post">Submit</button>
            </div>
      
     </div>
     </form>
  </body>
</html>

<?php
// EDIT USER: if admin clicks sumbit button
if (isset($_POST['adminEditUser'])) {
  // receive all input values from the form
	// sanitize data, and prevent injection
  $userID = mysqli_real_escape_string($db, $_POST['userID']);
  //$newEmail = mysqli_real_escape_string($db, $_POST['newEmail']);
	$newFirstName = mysqli_real_escape_string($db, $_POST['newFirstName']);
  $newLastName = mysqli_real_escape_string($db, $_POST['newLastName']);
	$errors = array();
  
  // check the database for user does not already exist with same email
  /*$user_check_query = "SELECT * FROM User WHERE email LIKE '$newEmail' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = $result->fetch_assoc();
  
  if ($user) { // if user exists
    if ($user['userID'] != $userID && $user['email'] === $newEmail) {
      array_push($errors, "The email address already exists");
    }
  }*/

  // Finally, add task if there are no errors in the form
  //if (count($errors) == 0) {

    /*if($newEmail != null){
        $query = "UPDATE User SET email='$newEmail' WHERE userID=$userID";
  	    mysqli_query($db, $query);
    }*/
  
  if($newFirstName != null){
        $query = "UPDATE User SET firstName='$newFirstName' WHERE userID=$userID";
  	    mysqli_query($db, $query);
    }
  
  if($newLastName != null){
        $query = "UPDATE User SET lastName='$newLastName' WHERE userID=$userID";
  	    mysqli_query($db, $query);
    }
   
  	$_SESSION['success'] = "The user has been succesfully updated";
  	header('location: adminViewUsers.php');
  //}
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}