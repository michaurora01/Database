<?php
//require_once('database.php'); 

session_start();

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'TaskDB');

// initializing variables
$email=$_SESSION['email'];
$result_user = "";
$userID = "";
$ownerID = "";
$groupID = "";
$taskName = "";
$category = "";
$dueDate = "";
$priority = "";
$descr = "";
$errors = array(); 

//$result_user ="CALL FindUserID($email)";
$result_user = $db->query("SELECT userID From User WHERE email='$email'");
$user1 = $result_user->fetch_assoc();
$userID = $user1['userID'];

// REGISTER USER: if user clicks sumbit button
if (isset($_POST['add_task'])) {
  // receive all input values from the form
	// sanitize data, and prevent injection
  $taskName = mysqli_real_escape_string($db, $_POST['taskName']);
	$category = mysqli_real_escape_string($db, $_POST['category']);
  $dueDate = mysqli_real_escape_string($db, $_POST['dueDate']);
	$priority = mysqli_real_escape_string($db, $_POST['priority']);
  $descr = mysqli_real_escape_string($db, $_POST['descr']);
	$errors = array();

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($taskName)) { array_push($errors, "Task name is required");}
  if (empty($category)) { array_push($errors, "Category is required");}
  if (empty($dueDate)) { array_push($errors, "Due date is required"); }
  if (empty($priority)) { array_push($errors, "Priority is required"); }
  if (empty($descr)) { array_push($errors, "Description is required"); }

  // Make sure due date is not more than 6 months in the future
  $now=new DateTime("now");
  $due=new DateTime($dueDate);
  $difference = date_diff($due,$now);
  if($difference->m > 6){
    array_push($errors, "Due dates must be less than 6 months in the future.");
  }
  
  // Finally, add task if there are no errors in the form
  if (count($errors) == 0) {

  	$query = "INSERT INTO Task (taskName, category, dueDate, priority, progress, description, completeDate, ownerID) 
  			  VALUES('$taskName', '$category', '$dueDate', '$priority', NULL, '$descr', NULL, '$userID')";
 
  	mysqli_query($db, $query);
  	$_SESSION['success'] = "Task is now added";
  	header('location: tasks.html');
  }
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}