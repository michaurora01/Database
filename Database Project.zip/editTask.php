<!DOCTYPE html>

<html>
  
  <style>
  body {font-family: Arial, Helvetica, sans-serif;}
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }
    
  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>
  
  <?php
    //require_once('database.php'); 

    session_start();

    // connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

    // initializing variables
    $email=$_SESSION['email'];
    $taskName = "";
    $result_user = "";
    $category = "";
    $dueDate = "";
    $priority = "";
    $descr = "";
    $errors = array(); 
  ?>
 
  <body>
    <form action="editTask.php" style="border:1px solid #ccc" method="post"> 
      
    <div class="container">
        <h1>Edit Task</h1>
        <hr>
      
        <?php
          // Find userID
          $result_user = $db->query("SELECT userID From User WHERE email='$email'");
          $user = $result_user->fetch_assoc();
          $userID = $user['userID'];
      
          $query  = "SELECT taskName, taskID FROM Task JOIN User ON(ownerID=userID) WHERE userID='$userID'";
          $result = mysqli_query($db, $query);
        ?>
      
          <label for="taskID"><b>Task Name</b></label>
            <select name = "taskID">
              <?php
                while($row=mysqli_fetch_assoc($result)){
                  ?>
                  <option value = "<?php echo $row['taskID'];?>"><?php echo $row['taskName']; ?> </option>
                  <?php
                }
              ?>
            </select>
            <br>
            <br>

            <label for="category"><b> New Category</b></label>
            <input type="text" placeholder="Enter New Task Category" name="category">

            <label for="dueDate"><b>New Due Date</b></label>
            <input type="date" style="width:100%" placeholder="Select New Task Due Date" name="dueDate">
            <br> 

            <label for="priority"><b>New Priority</b></label>
            <select name="priority">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
            <br>    

            <label for="descr"><b>New Description</b></label>
            <input type="text" placeholder="Enter New Task Description" name="descr">


            <div class="clearfix">
              <button type="button" class="backbtn"><a href="tasks.html">Back</a></button>
              <button type="submit" class="signupbtn" name="editTask" formmethod="post">Submit</button>
            </div>
      
     </div>
     </form>
  </body>
</html>

<?php
// EDIT TASK: if user clicks sumbit button
if (isset($_POST['editTask'])) {
  // receive all input values from the form
	// sanitize data, and prevent injection
  $taskID = mysqli_real_escape_string($db, $_POST['taskID']);
	$category = mysqli_real_escape_string($db, $_POST['category']);
  $dueDate = mysqli_real_escape_string($db, $_POST['dueDate']);
	$priority = mysqli_real_escape_string($db, $_POST['priority']);
  $descr = mysqli_real_escape_string($db, $_POST['descr']);
	$errors = array();
  
  //if (empty($taskName)) { array_push($errors, "Task name is required");}
  //if (empty($category)) { array_push($errors, "Category is required");}
  //if (empty($dueDate)) { array_push($errors, "Due date is required"); }
  //if (empty($priority)) { array_push($errors, "Priority is required"); }
  //if (empty($descr)) { array_push($errors, "Description is required"); }

  // Make sure due date is not more than 6 months in the future
  $now=new DateTime("now");
  $due=new DateTime($dueDate);
  $difference = date_diff($due,$now);
  //array_push($errors, $difference->m);
  if($difference->m > 6){
    array_push($errors, "Due dates must be less than 6 months in the future.");
  }
  
  // Finally, add task if there are no errors in the form
  if (count($errors) == 0) {

    if($category != null){
        $query = "UPDATE Task SET category='$category' WHERE taskID=$taskID";
  	    mysqli_query($db, $query);
    }
  
  if($dueDate != null){
        $query = "UPDATE Task SET dueDate='$dueDate' WHERE taskID=$taskID";
  	    mysqli_query($db, $query);
    }
  
  if($priority != null){
        $query = "UPDATE Task SET priority='$priority' WHERE taskID=$taskID";
  	    mysqli_query($db, $query);
    }
  
  if($descr != null){
        $query = "UPDATE Task SET description='$descr' WHERE taskID=$taskID";
  	    mysqli_query($db, $query);
    }
   
  	$_SESSION['success'] = "The task has been succesfully updated";
  	header('location: task_info.php');
  }
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}