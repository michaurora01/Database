<!DOCTYPE html>

<html>
  
  <style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("https://preview.ibb.co/n7g2jH/Light_desktop_hd_wallpapers.jpg");
    background-size: 1920px 1200px;
    padding-bottom: 70px;
  }
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }

  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>
  
  <?php
  //require_once('database.php'); 

  session_start();

  // connect to the database
  $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

  // initializing variables
  $email=$_SESSION['email'];
  $taskID = "";
  $taskName = "";
  $dueDate = "";
  $priority = "";
  $progress = "";
  $description = "";
  $completeDate = "";
  $category = "";
  $user1 = "";
  $errors = array(); 
  $oneRow = "";
  ?>

  <body>
    <form action="task_info.php" style="border:1px solid #ccc" method="post"> 
      
    <div class="container">
        <h1>All Tasks</h1>
        <hr>
      
      <?php

      $query  = "SELECT taskID, taskName, category, priority, ownerID, description, DATE_FORMAT(progress, '%M %D, %Y %H') AS the_progress, DATE_FORMAT(dueDate, '%M %D, %Y %H') AS due_date, DATE_FORMAT(completeDate, '%M %D, %Y %H') AS complete_date FROM Task";
      $result = mysqli_query($db, $query);
      
      ?>
          <?php
            // For each task
            while($row=mysqli_fetch_assoc($result)){
              
              // Find groupName(s)
              $res=$row['taskID'];
              $result_group = $db->query("SELECT groupName From Assignment NATURAL JOIN Groups WHERE taskID=$res");
              
              // Find owner
              $result_owner = $db->query("SELECT firstName, lastName From Task JOIN User ON (ownerID=userID) WHERE taskID=$res");
              $owner = $result_owner->fetch_assoc();
              ?>
      
              <h2><strong><?php echo $row['taskName']; ?></strong></h2>
              <p><strong>Description: </strong><small><?php echo $row['description'];?> </small></p>
              <p><strong>Category: </strong><small><?php echo $row['category'];?> </small></p>
              <p><strong>Priority: </strong><small><?php echo $row['priority'];?> </small></p>
              <p><strong>Due Date: </strong><small><?php echo $row['due_date']; echo ":00";?> </small></p>
              <p><strong>Last Progress: </strong><small><?php if($row['the_progress'] != null) {echo $row['the_progress']; echo ":00";} else {echo "No progress yet";}?> </small></p>
              <p><strong>Date Completed: </strong><small><?php if($row['complete_date'] != null) {echo $row['complete_date']; echo ":00";} else {echo "Not yet";}?> </small></p>
              <p><strong>Task Owner: </strong><small><?php echo $owner['firstName']; echo " "; echo $owner['lastName']; ?></small></p>
              <p><strong>Group(s): </strong><small>
                <?php while($row2=mysqli_fetch_assoc($result_group)){
                  echo $row2['groupName'];
                ?><br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php
              }?> </small>
              <hr></hr>
              <?php
            }
          ?>
          <div class = "clearfix">
            <button type="button" class="backbtn"><a href="adminPage.html">Back</a></button>
          <div>
      </div>
    </form>
</html>