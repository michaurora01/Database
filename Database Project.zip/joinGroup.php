<!DOCTYPE html>
<html>
  
  <style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("https://preview.ibb.co/n7g2jH/Light_desktop_hd_wallpapers.jpg");
    background-size: 1920px 1200px;
    padding-bottom: 70px;
  }
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }

  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>

<body>
    <form action="joinGroup.php" style="border:1px solid #ccc" method="post"> 
    <div class="container">
        <h1>Join a Group</h1>
        <hr>
      
      <?php
        session_start();

        // connect to the database
        $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

        // initializing variables
        $allGroups = "";
        $result_allGroups = "";
        $allGroupNames = "";
        $errors = array(); 

        // Find groupID
        $result_allGroups = $db->query("SELECT * FROM Groups");

            // Error if no groups are found
            if ($result_allGroups->num_rows === 0){
              echo "There are no groups yet. Go to the Create Group page to create a group.";
              header('location: home.php');
            }
        ?>
      
        <label for="groupID"><b>Group</b></label>
        <select name="groupID">
              <?php
                while($row=mysqli_fetch_assoc($result_allGroups)){
                  ?>
                  <option value = "<?php echo $row['groupID'];?>"><?php echo $row['groupName']; ?> </option>
                  <?php
                }
              ?>
            </select>
            <br>

        <div class="clearfix">
          <button type="button" class="backbtn"><a href="groups.html">Back</a></button>
          <button type="submit" class="signupbtn" name="joinGroup" formmethod="post">Join</button>
        </div>
            
     </div>
     </form>
  </body>
</html>
<?php

// initializing variables
$email=$_SESSION['email'];
$result_user = "";
$user1 = "";
$userID = "";
$group1 = "";
$result_group = "";
$groupID = "";
$errors = array(); 

// JOIN GROUP: if user clicks sumbit button
if (isset($_POST['joinGroup'])) {
  
  // receive all input values from the form
	// sanitize data, and prevent injection
  $groupID = mysqli_real_escape_string($db, $_POST['groupID']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($groupID)) { array_push($errors, "Group is required.");}

  // Finally, add task if there are no errors in the form
  if (count($errors) == 0) {
    
    // Find userID
    $result_user = $db->query("SELECT userID From User WHERE email='$email'");
    
    // Error if no matching user is found
    if ($result_user->num_rows === 0){
      echo "There was an error with your email, $email.";
      exit;
    }
    $user1 = $result_user->fetch_assoc();
    $userID = $user1['userID'];
    
    // Create new membership
  	$query = "INSERT INTO Membership (userID, groupID) 
  			  VALUES('$userID', '$groupID')";
  	mysqli_query($db, $query);
    
  	$_SESSION['success'] = "You have joined the group";
  	header('location: home.php');
  }
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}