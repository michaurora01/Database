<?php
$db_server = "localhost";
$db_user = "root";
$db_pwd = "";
$db_name = "TaskDB";

$link = new mysqli($db_server, $db_user, $db_pwd, $db_name);
if(!$link->connect_errno){
  echo "connected";
}
?>