<!DOCTYPE html>

<html>
  
  <style>
  body {font-family: Arial, Helvetica, sans-serif;}
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }
    
  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>
  
  <?php
    //require_once('database.php'); 

    session_start();

    // connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

    // initializing variables
    $email=$_SESSION['email'];
    $taskName = "";
    $result_user = "";
    $category = "";
    $dueDate = "";
    $priority = "";
    $descr = "";
    $errors = array(); 
  ?>
 
  <body>
    <form action="updateProgress.php" style="border:1px solid #ccc" method="post"> 
      
    <div class="container">
        <h1>Update the Progress of a Task</h1>
        <hr>
      
        <?php
          // Find userID
          $result_user = $db->query("SELECT userID From User WHERE email='$email'");
          $user = $result_user->fetch_assoc();
          $userID = $user['userID'];
      
          $query  = "(SELECT taskName, taskID FROM Task JOIN User ON(ownerID=userID) WHERE userID='$userID') UNION (SELECT taskName, taskID FROM Task NATURAL JOIN Assignment NATURAL JOIN Membership NATURAL JOIN User WHERE userID='$userID')";
          $result = mysqli_query($db, $query);
        ?>
      
          <label for="taskID"><b>Task Name</b></label>
            <select name = "taskID">
              <?php
                while($row=mysqli_fetch_assoc($result)){
                  ?>
                  <option value = "<?php echo $row['taskID'];?>"><?php echo $row['taskName']; ?> </option>
                  <?php
                }
              ?>
            </select>

            <div class="clearfix">
              <button type="button" class="backbtn"><a href="tasks.html">Back</a></button>
              <button type="submit" class="signupbtn" name="updateProgress" formmethod="post">Update Progress</button>
            </div>
      
     </div>
     </form>
  </body>
</html>

<?php
// UPDATE PROGRESS: if user clicks sumbit button
if (isset($_POST['updateProgress'])) {
  // receive all input values from the form
	// sanitize data, and prevent injection
  $taskID = mysqli_real_escape_string($db, $_POST['taskID']);
	$errors = array();

    if($taskID != null){
        $query = "UPDATE Task SET progress=NOW() WHERE taskID=$taskID";
  	    mysqli_query($db, $query);
    }
   
  	$_SESSION['success'] = "The progress of your task has been updated";
  	header('location: task_info.php');
  //}
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}