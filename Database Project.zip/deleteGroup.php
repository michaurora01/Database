<!DOCTYPE html>

<html>
  
  <style>
 body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("https://preview.ibb.co/n7g2jH/Light_desktop_hd_wallpapers.jpg");
    background-size: 1920px 1200px;
    padding-bottom: 70px;
  }
  * {box-sizing: border-box}

  /* Full-width input fields */
  input {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
  }

  input {
      background-color: #ddd;
      outline: none;
  }

  hr {
      border: 1px solid #f1f1f1;
      margin-bottom: 25px;
  }

  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }

  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
    
  /* style for dropdown */
  select {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      display: inline-block;
      border: none;
      background: #f1f1f1;
      border-radius:4px;
      color:#888;
      outline:none;
      appearance:none;
      cursor:pointer;
  }
  </style>
  
  <?php
  //require_once('database.php'); 

  session_start();

  // connect to the database
  $db = mysqli_connect('localhost', 'root', '', 'TaskDB');

  // initializing variables
  $email=$_SESSION['email'];
  $groupName = "";
  $user1 = "";
  $errors = array(); 
  ?>
  
  <body>
    <form action="deleteGroup.php" style="border:1px solid #ccc" method="post"> 
      
    <div class="container">
        <h1>Select A Group To Delete</h1>
        <hr>

       <?php
      // Find userID from table
      $result_user = $db->query("SELECT userID From User WHERE email='$email'");
      $user1 = $result_user->fetch_assoc();
      $userID = $user1['userID'];

      $query  = "(SELECT groupName, groupID FROM Groups WHERE ownerID='$userID')";
      $result = mysqli_query($db, $query);
      ?>
          <select name="groupID">
            <?php
              while($row=mysqli_fetch_assoc($result)){
                ?>
                <option value = "<?php echo $row['groupID'];?>"><?php echo $row['groupName']; ?> </option>
                <?php
              }
            ?>
          </select>
      
      
      
      <div class="clearfix">
          <button type="button" class="backbtn"><a href="groups.html">Back</a></button>
          <button type="submit" class="signupbtn" name="delete_group" formmethod="post">Delete Group</button>
        </div>
      </div>
    </form>
  </body>
</html>

<?php

// initializing variables
$email=$_SESSION['email'];
$groupID="";
$errors = array(); 

// DELETE TASK: if user clicks submit button
if (isset($_POST['delete_group'])) {

  // Finally, add task if there are no errors in the form
  if (count($errors) == 0) {
    
    // set taskID to selected value
    $groupID = $_POST['groupID'];
    
    // delete group from table
  	$query = "DELETE FROM Groups WHERE groupID = '$groupID'";
  	mysqli_query($db, $query);
    
  	$_SESSION['success'] = "You have deleted the group";
  	header('location: viewGroups.php');
  }
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}
?>