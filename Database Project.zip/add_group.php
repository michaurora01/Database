<?php
//require_once('database.php'); 

session_start();

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'TaskDB');

// initializing variables
$email=$_SESSION['email'];
$groupName = "";
$userID = "";
$errors = array(); 

// create group: if user clicks sumbit button
if (isset($_POST['add_group'])) {
  // receive all input values from the form
	// sanitize data, and prevent injection
  $groupName = mysqli_real_escape_string($db, $_POST['groupName']);
	$errors = array();
  
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($groupName)) { array_push($errors, "Group name is required");}


  // Finally, add task if there are no errors in the form
  if (count($errors) == 0) {  
     // Find userID
    $result_user = $db->query("SELECT userID From User WHERE email='$email'");
    
    // Error if no matching user is found
    if ($result_user->num_rows === 0){
      echo "There was an error with your email, $email.";
      exit;
    }
    $user1 = $result_user->fetch_assoc();
    $userID = $user1['userID'];
    
    $query = "INSERT INTO Groups (groupName, ownerID) 
  			  VALUES('$groupName', '$userID')";
    mysqli_query($db, $query);
    
    // Create new membership
  	$query = "INSERT INTO Membership (userID, groupID) 
  			  VALUES('$userID', '$groupID')";
  	mysqli_query($db, $query);

  	$_SESSION['success'] = "Group is now created";
  	header('location: groups.html');
  }
	
	//print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}