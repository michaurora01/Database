<?php
//require_once('database.php');

session_start();

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'TaskDB');

// Initialize variables
$email="";
$errors=array();

if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  
  // Check for empty email
  if (empty($email)) {
    array_push($errors, "Email address is required.");
  }
  
  // Check for empty password
  if (empty($password)) {
    array_push($errors, "Password is required.");
  }
  
  // if no errors
  if (count($errors) == 0) {
    $password = md5($password);
    $query = "SELECT * FROM User WHERE email='$email' AND password='$password'";
    $results = mysqli_query($db, $query);
    
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in.";
      header('location: home.php');
    }else {
      array_push($errors, "Wrong username/password combination.");
    }
  }
  
  //print errors from errors list if any
	if (count($errors) > 0) : ?>
  <div class="error">
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
	<?php  endif; 
}
?>


