<?php
  session_start();
$db = mysqli_connect('localhost', 'root', '', 'TaskDB');
  if(!isset($_SESSION['email'])){
    $_SESSION['msg']="You must log in first.";
    header('location: login.html');
  }
  if (isset($_GET['logout'])){
      session_destroy();
      unset($_SESSION['email']);
      header("location: login.html");
  }
?>
<!DOCTYPE html>
<html>
  
  <style>
    
  body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("https://preview.ibb.co/n7g2jH/Light_desktop_hd_wallpapers.jpg");
    background-size: 1920px 1200px;
    padding-bottom: 70px;
  }
  * {box-sizing: border-box}
  /* Set a style for all buttons */
  button {
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 100%;
      opacity: 0.9;
  }

  button:hover {
      opacity:1;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
      padding: 14px 20px;
      background-color: #f44336;
  }

  /* Float cancel and signup buttons and add an equal width */
  .cancelbtn, .signupbtn, .backbtn {
    float: left;
    width: 50%;
  }
    
   .backbtn {
      padding: 14px 20px;
      background-color: #008CBA;
  }

  /* Add padding to container elements */
  .container {
      padding: 16px;
  }

  /* Clear floats */
  .clearfix::after {
      content: "";
      clear: both;
      display: table;
  }
  </style>
  
  <head>
    <meta charset="utf-8">
    <title>Group 4</title>
  </head>
  
    <?php
    // Find userID
    $email=$_SESSION['email'];
    $result_user = $db->query("SELECT userID From User WHERE email='$email'");
    $user1 = $result_user->fetch_assoc();
    $userID = $user1['userID'];?>
  
  <body>    
     <h1>Welcome,  <?php echo $_SESSION['email'];?>!</h1>
  
  <form action="tasks.html" style="border:1px solid #ccc" method="post"> 
                <div class="clearfix">
                  <button type="submit" class="backbtn" name="manageTasks" formmethod="post">Manage Tasks</button>
                </div>
          </form>
  
  <form action="groups.html" style="border:1px solid #ccc" method="post"> 
                <div class="clearfix">
                  <button type="submit" class="backbtn" name="manageGroups" formmethod="post">Manage Groups</button>
                </div>
          </form>
    
    <?php
    $result_ad = $db->query("SELECT isAdmin From User WHERE userID='$userID'");
    $ad1 = $result_ad->fetch_assoc();
    $isAd = $ad1['isAdmin'];
    if($isAd){
      ?>
    <form action="adminPage.html" style="border:1px solid #ccc" method="post"> 
                <div class="clearfix">
                  <button type="submit" class="backbtn" name="admin" formmethod="post">Admin Pages</button>
                </div>
     </form>
    <?php
    }
    ?>
  
  <?php if (isset($_SESSION['email'])) : ?>
    <div class="clearfix">
      <p> <a href="home.php?logout='1'" style="color: white;" type="button" class="cancelbtn">Logout</a> </p>
    </div>
  <?php endif ?>
</html>
